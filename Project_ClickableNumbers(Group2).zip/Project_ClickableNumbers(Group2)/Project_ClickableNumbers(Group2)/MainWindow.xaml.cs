﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project_ClickableNumbers_Group2_
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_NumberClick(object sender, RoutedEventArgs e)
        {
            var buttonTemp = sender as Button;
            switch (buttonTemp.Name)
            {
                case "button_One":
                    MessageBox.Show("One");
                    break;
                case "button_Two":
                    MessageBox.Show("Two");
                    break;
                case "button_Three":
                    MessageBox.Show("Three");
                    break;
                case "button_Four":
                    MessageBox.Show("Four");
                    break;
                case "button_Five":
                    MessageBox.Show("Five");
                    break;
                default:
                    break;

            }
        }
    }
}
